// This file is intentionally minimal since the EXIF reader
// is a client-side only application with no database requirements
export {};