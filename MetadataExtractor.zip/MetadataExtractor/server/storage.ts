// This EXIF reader is a client-side only application
// No storage is needed as all processing happens in the browser
export {};